# VRCRip

Scans VRChat avatar cache on Quest 2/3, lists found bundles, copies them to `/sdcard/VRCRip/avatars/` as `.vrca` files.

## Build

The Android Gradle project is inside the `VRCRip_full/` directory. Run build commands
from that directory (the GitHub Actions workflow already sets this working directory).


```bash
# Android Studio or command line
./gradlew assembleDebug
# APK at: app/build/outputs/apk/debug/app-debug.apk
```

## Sideload

```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

## Storage permission (Android 11+ / Quest OS 5+)

App will prompt on first scan. If the dialog doesn't appear:

```bash
adb shell appops set com.vrc.rip MANAGE_EXTERNAL_STORAGE allow
adb shell pm grant com.vrc.rip android.permission.READ_EXTERNAL_STORAGE
adb shell pm grant com.vrc.rip android.permission.WRITE_EXTERNAL_STORAGE
```

## Cache paths checked

VRCRip checks (in order):
- `Android/data/com.vrchat.mobile.playstation/files/Oculus/`
- `Android/data/com.vrchat.mobile.playstation/files/cache/`
- `Android/data/com.vrchat.mobile.playstation/cache/`
- `Android/data/com.vrchat/files/cache/`
- `Android/data/com.vrchat/cache/`
- Fallback: scans any `com.vrchat*` package under `Android/data/`

## Output

Ripped files land at `/sdcard/VRCRip/avatars/<avtr_ID>.vrca`

Pull via ADB:
```bash
adb pull /sdcard/VRCRip/avatars/ ./ripped_avatars/
```

## What the VRCA files are

Unity AssetBundles for ARM64 Quest. To extract meshes/textures from them use:
- **AssetRipper** (PC) — full extraction to FBX + textures
- **UABEA** — raw asset editing
- **uTinyRipper** — legacy alternative

The files are valid for the Unity version shown in the list (VRChat Mobile currently uses Unity 2022.3.x).

## Notes

- VRChat must have been launched and avatars loaded for cache to exist
- Cache entries are per-platform: PC and Quest caches are separate
- Compression type 3 (LZ4) is most common on Quest builds
