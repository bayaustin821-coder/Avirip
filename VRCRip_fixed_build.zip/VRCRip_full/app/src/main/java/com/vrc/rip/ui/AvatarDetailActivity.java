// AvatarDetailActivity.java
// Shows full avatar info, download button, upload-to-VRChat button
// Receives BundleInfo fields via Intent extras
package com.vrc.rip.ui;

import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.JsonObject;
import com.vrc.rip.R;
import com.vrc.rip.core.RipManager;
import com.vrc.rip.core.VrcaParser;
import com.vrc.rip.network.VRChatApiManager;

import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AvatarDetailActivity extends AppCompatActivity {

    public static final String EXTRA_FILE_PATH    = "file_path";
    public static final String EXTRA_AVATAR_ID    = "avatar_id";
    public static final String EXTRA_BUNDLE_SIZE  = "bundle_size";
    public static final String EXTRA_COMPRESSION  = "compression";
    public static final String EXTRA_UNITY_VER    = "unity_ver";
    public static final String EXTRA_THUMB        = "thumb_bytes"; // byte[]

    private ImageView ivThumb;
    private TextView tvAvatarId, tvSize, tvPath, tvStatus, tvUnityVer;
    private Button btnDownload, btnUpload;
    private EditText etUploadName;
    private ProgressBar progressBar;

    private VrcaParser.BundleInfo info;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_avatar_detail);

        ivThumb    = findViewById(R.id.iv_thumb_large);
        tvAvatarId = findViewById(R.id.tv_detail_avatar_id);
        tvSize     = findViewById(R.id.tv_detail_size);
        tvPath     = findViewById(R.id.tv_detail_path);
        tvStatus   = findViewById(R.id.tv_detail_status);
        tvUnityVer = findViewById(R.id.tv_detail_unity_ver);
        btnDownload = findViewById(R.id.btn_download);
        btnUpload   = findViewById(R.id.btn_upload);
        etUploadName = findViewById(R.id.et_upload_name);
        progressBar = findViewById(R.id.progress_bar);

        // reconstruct BundleInfo from intent
        info = new VrcaParser.BundleInfo();
        info.filePath        = getIntent().getStringExtra(EXTRA_FILE_PATH);
        info.avatarId        = getIntent().getStringExtra(EXTRA_AVATAR_ID);
        info.uncompressedSize = getIntent().getLongExtra(EXTRA_BUNDLE_SIZE, 0);
        info.compressionType  = getIntent().getIntExtra(EXTRA_COMPRESSION, 0);
        info.bundleVersion    = getIntent().getStringExtra(EXTRA_UNITY_VER);
        info.thumbnailPng     = getIntent().getByteArrayExtra(EXTRA_THUMB);
        info.isValid          = true;

        populateUI();

        btnDownload.setOnClickListener(v -> downloadAvatar());
        btnUpload.setOnClickListener(v -> uploadAvatar());

        // hide upload if not logged in
        if (!VRChatApiManager.get(this).isLoggedIn()) {
            btnUpload.setVisibility(View.GONE);
            etUploadName.setVisibility(View.GONE);
            tvStatus.setText("Log in to enable upload.");
        }
    }

    private void populateUI() {
        tvAvatarId.setText(info.avatarId);
        tvSize.setText(formatSize(info.uncompressedSize));
        tvPath.setText(info.filePath);
        tvUnityVer.setText(info.bundleVersion != null ? info.bundleVersion : "unknown");
        etUploadName.setText(info.avatarId);

        if (info.thumbnailPng != null && info.thumbnailPng.length > 0) {
            try {
                ivThumb.setImageBitmap(
                    BitmapFactory.decodeByteArray(info.thumbnailPng, 0, info.thumbnailPng.length));
            } catch (Exception ignored) {}
        }
    }

    private void downloadAvatar() {
        setLoading(true, "Copying to /sdcard/VRCRip/avatars/...");
        executor.execute(() -> {
            File out = RipManager.ripSingle(info);
            mainHandler.post(() -> {
                setLoading(false, null);
                if (out != null) {
                    tvStatus.setText("Saved: " + out.getAbsolutePath()
                        + "\n\nPull via ADB:\nadb pull " + out.getAbsolutePath());
                } else {
                    tvStatus.setText("Download failed — check storage permission.");
                }
            });
        });
    }

    private void uploadAvatar() {
        String uploadName = etUploadName.getText().toString().trim();
        if (uploadName.isEmpty()) uploadName = info.avatarId;

        File vrcaFile = new File(info.filePath);
        if (!vrcaFile.exists()) {
            // try ripped output dir first
            vrcaFile = new File(RipManager.getOutputDir(), info.avatarId + ".vrca");
            if (!vrcaFile.exists()) {
                tvStatus.setText("File not found. Download it first.");
                return;
            }
        }

        setLoading(true, "Uploading to VRChat...");
        final File finalFile = vrcaFile;
        final String finalName = uploadName;

        VRChatApiManager.get(this).uploadAvatar(
            info.avatarId, finalName, finalFile, info.thumbnailPng,
            new VRChatApiManager.ApiCallback<JsonObject>() {
                @Override public void onSuccess(JsonObject result) {
                    String newId = result.has("id") ? result.get("id").getAsString() : "?";
                    mainHandler.post(() -> {
                        setLoading(false, null);
                        tvStatus.setText("Uploaded! VRChat avatar ID: " + newId
                            + "\n\nVisible in your VRChat avatars as private.");
                        btnUpload.setEnabled(false);
                        btnUpload.setText("Uploaded ✓");
                    });
                }
                @Override public void onError(String error, int code) {
                    mainHandler.post(() -> {
                        setLoading(false, null);
                        tvStatus.setText("Upload failed [" + code + "]: " + error);
                    });
                }
            }
        );
    }

    private void setLoading(boolean loading, String msg) {
        progressBar.setVisibility(loading ? View.VISIBLE : View.GONE);
        btnDownload.setEnabled(!loading);
        btnUpload.setEnabled(!loading);
        if (msg != null) tvStatus.setText(msg);
    }

    private static String formatSize(long bytes) {
        if (bytes <= 0) return "?";
        if (bytes < 1024 * 1024) return (bytes / 1024) + " KB";
        return String.format("%.1f MB", bytes / (1024.0 * 1024));
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        executor.shutdown();
    }
}
