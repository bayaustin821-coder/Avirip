// AvatarListAdapter.java v2 — tap item to open detail, long-press to quick-rip
package com.vrc.rip.ui;

import android.graphics.BitmapFactory;
import android.view.*;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.vrc.rip.R;
import com.vrc.rip.core.VrcaParser;

import java.util.*;

public class AvatarListAdapter extends RecyclerView.Adapter<AvatarListAdapter.ViewHolder> {

    public interface OnItemClickListener {
        void onTap(VrcaParser.BundleInfo info);
    }

    private final List<VrcaParser.BundleInfo> items;
    private final Set<Integer> rippedPositions = new HashSet<>();
    private final OnItemClickListener listener;

    public AvatarListAdapter(List<VrcaParser.BundleInfo> items, OnItemClickListener listener) {
        this.items = items;
        this.listener = listener;
    }

    public void markRipped(int position) {
        rippedPositions.add(position);
        notifyItemChanged(position);
    }

    @NonNull @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
            .inflate(R.layout.item_avatar, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int pos) {
        VrcaParser.BundleInfo info = items.get(pos);

        h.tvAvatarId.setText(info.avatarId);
        h.tvMeta.setText(formatSize(info.uncompressedSize)
            + "  ·  " + compressionLabel(info.compressionType)
            + "  ·  " + (info.bundleVersion != null ? info.bundleVersion : "?"));

        if (info.thumbnailPng != null && info.thumbnailPng.length > 0) {
            try {
                h.ivThumb.setImageBitmap(
                    BitmapFactory.decodeByteArray(info.thumbnailPng, 0, info.thumbnailPng.length));
            } catch (Exception e) {
                h.ivThumb.setImageResource(R.drawable.ic_avatar_placeholder);
            }
        } else {
            h.ivThumb.setImageResource(R.drawable.ic_avatar_placeholder);
        }

        boolean ripped = rippedPositions.contains(pos);
        h.tvRippedBadge.setVisibility(ripped ? View.VISIBLE : View.GONE);

        h.itemView.setOnClickListener(v -> {
            if (listener != null) listener.onTap(info);
        });
    }

    @Override public int getItemCount() { return items.size(); }

    private static String formatSize(long b) {
        if (b <= 0) return "?";
        if (b < 1024 * 1024) return (b / 1024) + " KB";
        return String.format("%.1f MB", b / (1024.0 * 1024));
    }

    private static String compressionLabel(int t) {
        switch (t) {
            case 0: return "Uncompressed";
            case 1: return "LZMA";
            case 3: return "LZ4";
            case 6: return "LZ4HC";
            default: return "Compressed";
        }
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView ivThumb;
        TextView tvAvatarId, tvMeta, tvRippedBadge;

        ViewHolder(View v) {
            super(v);
            ivThumb      = v.findViewById(R.id.iv_thumb);
            tvAvatarId   = v.findViewById(R.id.tv_avatar_id);
            tvMeta       = v.findViewById(R.id.tv_meta);
            tvRippedBadge = v.findViewById(R.id.tv_ripped_badge);
        }
    }
}
