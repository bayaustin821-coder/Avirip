// RipManager.java — copies validated bundles to /sdcard/VRCRip/avatars/
// Output filenames: avtr_XXXX.vrca so they're directly usable
package com.vrc.rip.core;

import android.os.Environment;
import android.util.Log;

import java.io.*;
import java.util.*;

public class RipManager {

    private static final String TAG = "RipManager";
    private static final String OUTPUT_DIR = "VRCRip/avatars";
    private static final int COPY_BUFFER = 1024 * 1024; // 1MB buffer

    public interface RipCallback {
        void onProgress(String avatarId, int current, int total);
        void onFileDone(String avatarId, File outFile, boolean success);
        void onAllDone(int successCount, int failCount, File outputDir);
    }

    /**
     * Copy a list of BundleInfos to output dir.
     * Skips files already present with same size (resume-friendly).
     */
    public static void ripAll(List<VrcaParser.BundleInfo> bundles, RipCallback callback) {
        File outDir = getOutputDir();
        if (!outDir.exists() && !outDir.mkdirs()) {
            Log.e(TAG, "Failed to create output dir: " + outDir);
            if (callback != null) callback.onAllDone(0, bundles.size(), outDir);
            return;
        }

        int success = 0, fail = 0;
        int total = bundles.size();

        for (int i = 0; i < total; i++) {
            VrcaParser.BundleInfo info = bundles.get(i);
            if (callback != null) callback.onProgress(info.avatarId, i + 1, total);

            File src = new File(info.filePath);
            String outName = sanitizeId(info.avatarId) + ".vrca";
            File dst = new File(outDir, outName);

            // skip if already ripped with same size
            if (dst.exists() && dst.length() == src.length()) {
                Log.d(TAG, "Skip (already exists): " + outName);
                success++;
                if (callback != null) callback.onFileDone(info.avatarId, dst, true);
                continue;
            }

            boolean ok = copyFile(src, dst);
            if (ok) {
                success++;
                Log.d(TAG, "Ripped: " + outName + " (" + dst.length() / 1024 + " KB)");
            } else {
                fail++;
                Log.e(TAG, "Failed to rip: " + src.getName());
            }

            if (callback != null) callback.onFileDone(info.avatarId, dst, ok);
        }

        if (callback != null) callback.onAllDone(success, fail, outDir);
    }

    /**
     * Rip a single bundle by index.
     */
    public static File ripSingle(VrcaParser.BundleInfo info) {
        File outDir = getOutputDir();
        outDir.mkdirs();

        File src = new File(info.filePath);
        File dst = new File(outDir, sanitizeId(info.avatarId) + ".vrca");
        return copyFile(src, dst) ? dst : null;
    }

    public static File getOutputDir() {
        return new File(Environment.getExternalStorageDirectory(), OUTPUT_DIR);
    }

    private static boolean copyFile(File src, File dst) {
        try (InputStream in  = new BufferedInputStream(new FileInputStream(src), COPY_BUFFER);
             OutputStream out = new BufferedOutputStream(new FileOutputStream(dst), COPY_BUFFER)) {
            byte[] buf = new byte[COPY_BUFFER];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return true;
        } catch (IOException e) {
            Log.e(TAG, "copyFile failed: " + src.getName(), e);
            dst.delete(); // clean partial write
            return false;
        }
    }

    private static String sanitizeId(String id) {
        // replace any char that's not alphanumeric, underscore, or hyphen
        return id.replaceAll("[^a-zA-Z0-9_\\-]", "_");
    }
}
