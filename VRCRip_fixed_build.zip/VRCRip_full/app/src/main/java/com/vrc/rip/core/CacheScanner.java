// CacheScanner.java — locates and enumerates VRChat avatar cache on Quest
// VRChat Mobile (Quest) cache paths vary by build; we check all known locations
// + do a targeted fallback search under /sdcard/Android/data/
package com.vrc.rip.core;

import android.content.Context;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.util.*;

public class CacheScanner {

    private static final String TAG = "CacheScanner";

    // known VRChat cache directories on Quest (checked in order)
    private static final String[] KNOWN_CACHE_PATHS = {
        // VRChat Mobile (current)
        "Android/data/com.vrchat.mobile.playstation/files/Oculus/",
        "Android/data/com.vrchat.mobile.playstation/files/cache/",
        "Android/data/com.vrchat.mobile.playstation/cache/",
        // older VRChat Quest builds
        "Android/data/com.vrchat/files/cache/",
        "Android/data/com.vrchat/cache/",
        // VRChat via App Lab
        "Android/data/com.vrchat.vrchat/files/cache/",
        "Android/data/com.vrchat.vrchat/cache/",
    };

    // avatar bundle extensions
    private static final Set<String> BUNDLE_EXTENSIONS = new HashSet<>(Arrays.asList(
        ".vrca", ".vrcw", ".vrca.gz", ""  // no extension (raw cache entries)
    ));

    public interface ScanCallback {
        void onFileFound(File file, int current, int total);
        void onScanComplete(List<VrcaParser.BundleInfo> results);
        void onError(String message);
    }

    /**
     * Scan all known VRChat cache paths, return parsed BundleInfo list.
     * Runs on caller's thread — wrap in AsyncTask/Thread/Coroutine.
     */
    public static List<VrcaParser.BundleInfo> scan(Context ctx, ScanCallback callback) {
        List<File> cacheRoots = findCacheRoots();

        if (cacheRoots.isEmpty()) {
            if (callback != null) callback.onError("No VRChat cache directories found. " +
                "Make sure VRChat has been launched at least once on this headset.");
            return Collections.emptyList();
        }

        List<File> allFiles = new ArrayList<>();
        for (File root : cacheRoots) {
            Log.d(TAG, "Scanning: " + root.getAbsolutePath());
            collectBundleFiles(root, allFiles);
        }

        Log.d(TAG, "Found " + allFiles.size() + " candidate files");

        List<VrcaParser.BundleInfo> results = new ArrayList<>();
        int total = allFiles.size();

        for (int i = 0; i < total; i++) {
            File f = allFiles.get(i);
            if (callback != null) callback.onFileFound(f, i + 1, total);

            VrcaParser.BundleInfo info = VrcaParser.parseHeader(f);
            if (info.isValid) {
                results.add(info);
                Log.d(TAG, "Valid bundle: " + info.avatarId + " (" + f.length() / 1024 + " KB)");
            }
        }

        if (callback != null) callback.onScanComplete(results);
        return results;
    }

    /**
     * Locate all existing VRChat cache root directories on this device.
     */
    public static List<File> findCacheRoots() {
        List<File> roots = new ArrayList<>();
        File sdcard = Environment.getExternalStorageDirectory();

        // check known paths first
        for (String rel : KNOWN_CACHE_PATHS) {
            File dir = new File(sdcard, rel);
            if (dir.exists() && dir.isDirectory()) {
                roots.add(dir);
                Log.d(TAG, "Found cache root: " + dir.getAbsolutePath());
            }
        }

        // fallback: walk Android/data/ looking for any com.vrchat* package
        if (roots.isEmpty()) {
            File androidData = new File(sdcard, "Android/data/");
            if (androidData.exists()) {
                File[] packages = androidData.listFiles();
                if (packages != null) {
                    for (File pkg : packages) {
                        if (pkg.getName().startsWith("com.vrchat")) {
                            // look for cache or files subdirs
                            for (String sub : new String[]{"files/cache", "cache", "files"}) {
                                File candidate = new File(pkg, sub);
                                if (candidate.exists() && candidate.isDirectory()) {
                                    roots.add(candidate);
                                    Log.d(TAG, "Fallback found: " + candidate.getAbsolutePath());
                                }
                            }
                        }
                    }
                }
            }
        }

        return roots;
    }

    /**
     * Recursively collect all files that look like Unity bundles.
     * VRChat caches files with no extension (pure hash names) — we include those too
     * and let VrcaParser validate by magic bytes.
     */
    private static void collectBundleFiles(File dir, List<File> out) {
        File[] entries = dir.listFiles();
        if (entries == null) return;

        for (File entry : entries) {
            if (entry.isDirectory()) {
                collectBundleFiles(entry, out); // recurse
            } else if (entry.isFile() && entry.length() > 512) {
                // include if extension matches OR no extension (raw cache hash)
                String name = entry.getName();
                String ext = name.contains(".") ? name.substring(name.lastIndexOf('.')) : "";
                if (BUNDLE_EXTENSIONS.contains(ext.toLowerCase())) {
                    out.add(entry);
                }
            }
        }
    }
}
