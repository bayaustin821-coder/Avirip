// MainActivity.java v2 — scan + filter + per-avatar detail tap + logout
package com.vrc.rip.ui;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.*;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.vrc.rip.R;
import com.vrc.rip.core.*;
import com.vrc.rip.network.VRChatApiManager;
import com.vrc.rip.util.StoragePermissionHelper;

import java.io.File;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.Collectors;

public class MainActivity extends AppCompatActivity {

    private TextView tvStatus, tvAccountInfo;
    private ProgressBar progressBar;
    private Button btnScan, btnRipAll, btnLogout;
    private EditText etSearch;
    private Spinner spinnerFilter;
    private RecyclerView rvAvatars;

    private AvatarListAdapter adapter;
    private List<VrcaParser.BundleInfo> allBundles = new ArrayList<>();
    private List<VrcaParser.BundleInfo> filteredBundles = new ArrayList<>();

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    // filter options
    private static final String[] FILTER_OPTIONS = {
        "All", "LZ4 only", "LZMA only", "No compression", "> 10 MB", "< 1 MB"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvStatus      = findViewById(R.id.tv_status);
        tvAccountInfo = findViewById(R.id.tv_account_info);
        progressBar   = findViewById(R.id.progress_bar);
        btnScan       = findViewById(R.id.btn_scan);
        btnRipAll     = findViewById(R.id.btn_rip_all);
        btnLogout     = findViewById(R.id.btn_logout);
        etSearch      = findViewById(R.id.et_search);
        spinnerFilter = findViewById(R.id.spinner_filter);
        rvAvatars     = findViewById(R.id.rv_avatars);

        rvAvatars.setLayoutManager(new LinearLayoutManager(this));

        // account header
        VRChatApiManager api = VRChatApiManager.get(this);
        if (api.isLoggedIn()) {
            tvAccountInfo.setText("Logged in as " + api.getDisplayName());
        } else {
            tvAccountInfo.setText("Not logged in — upload disabled");
        }

        // filter spinner
        ArrayAdapter<String> spinAdapter = new ArrayAdapter<>(this,
            android.R.layout.simple_spinner_item, FILTER_OPTIONS);
        spinAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerFilter.setAdapter(spinAdapter);
        spinnerFilter.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) { applyFilter(); }
            @Override public void onNothingSelected(AdapterView<?> p) {}
        });

        // search box
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            @Override public void onTextChanged(CharSequence s, int st, int b, int c) { applyFilter(); }
            @Override public void afterTextChanged(Editable s) {}
        });

        btnScan.setOnClickListener(v -> {
            if (!StoragePermissionHelper.hasStoragePermission(this)) {
                StoragePermissionHelper.requestStoragePermission(this);
                tvStatus.setText("Grant storage permission, then tap Scan.\n\nADB:\n"
                    + StoragePermissionHelper.getAdbGrantCommand(getPackageName()));
                return;
            }
            startScan();
        });

        btnRipAll.setOnClickListener(v -> ripAll());
        btnRipAll.setEnabled(false);

        btnLogout.setOnClickListener(v -> {
            VRChatApiManager.get(this).logout();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });
    }

    private void startScan() {
        btnScan.setEnabled(false);
        btnRipAll.setEnabled(false);
        progressBar.setVisibility(View.VISIBLE);
        progressBar.setIndeterminate(true);
        tvStatus.setText("Scanning VRChat cache...");
        allBundles.clear();
        filteredBundles.clear();

        executor.execute(() -> {
            List<VrcaParser.BundleInfo> results = CacheScanner.scan(this, new CacheScanner.ScanCallback() {
                @Override public void onFileFound(File file, int current, int total) {
                    mainHandler.post(() -> {
                        progressBar.setIndeterminate(false);
                        progressBar.setMax(total);
                        progressBar.setProgress(current);
                        tvStatus.setText("Scanning " + current + "/" + total + "  " + file.getName());
                    });
                }
                @Override public void onScanComplete(List<VrcaParser.BundleInfo> r) {}
                @Override public void onError(String message) {
                    mainHandler.post(() -> {
                        tvStatus.setText(message);
                        progressBar.setVisibility(View.GONE);
                        btnScan.setEnabled(true);
                    });
                }
            });

            mainHandler.post(() -> {
                allBundles = results;
                progressBar.setVisibility(View.GONE);
                btnScan.setEnabled(true);

                if (results.isEmpty()) {
                    tvStatus.setText("No avatar bundles found. Launch VRChat first to populate the cache.");
                } else {
                    tvStatus.setText("Found " + results.size() + " bundle(s)");
                    btnRipAll.setEnabled(true);
                    applyFilter();
                }
            });
        });
    }

    private void applyFilter() {
        String query = etSearch.getText().toString().toLowerCase().trim();
        int filterPos = spinnerFilter.getSelectedItemPosition();

        filteredBundles = allBundles.stream().filter(info -> {
            // text filter
            if (!query.isEmpty() && !info.avatarId.toLowerCase().contains(query)) return false;
            // compression / size filter
            switch (filterPos) {
                case 1: return info.compressionType == 3;   // LZ4
                case 2: return info.compressionType == 1;   // LZMA
                case 3: return info.compressionType == 0;   // None
                case 4: return info.uncompressedSize > 10 * 1024 * 1024;
                case 5: return info.uncompressedSize < 1024 * 1024;
                default: return true;
            }
        }).collect(Collectors.toList());

        tvStatus.setText("Showing " + filteredBundles.size() + " / " + allBundles.size() + " bundle(s)");

        adapter = new AvatarListAdapter(filteredBundles, info -> {
            // tap → detail activity
            Intent intent = new Intent(this, AvatarDetailActivity.class);
            intent.putExtra(AvatarDetailActivity.EXTRA_FILE_PATH, info.filePath);
            intent.putExtra(AvatarDetailActivity.EXTRA_AVATAR_ID, info.avatarId);
            intent.putExtra(AvatarDetailActivity.EXTRA_BUNDLE_SIZE, info.uncompressedSize);
            intent.putExtra(AvatarDetailActivity.EXTRA_COMPRESSION, info.compressionType);
            intent.putExtra(AvatarDetailActivity.EXTRA_UNITY_VER, info.bundleVersion);
            intent.putExtra(AvatarDetailActivity.EXTRA_THUMB, info.thumbnailPng);
            startActivity(intent);
        });
        rvAvatars.setAdapter(adapter);
    }

    private void ripAll() {
        if (filteredBundles.isEmpty()) return;
        btnRipAll.setEnabled(false);
        progressBar.setVisibility(View.VISIBLE);
        progressBar.setIndeterminate(false);
        progressBar.setMax(filteredBundles.size());

        executor.execute(() -> RipManager.ripAll(filteredBundles, new RipManager.RipCallback() {
            @Override public void onProgress(String avatarId, int current, int total) {
                mainHandler.post(() -> {
                    progressBar.setProgress(current);
                    tvStatus.setText("Ripping " + current + "/" + total + " — " + avatarId);
                });
            }
            @Override public void onFileDone(String avatarId, File outFile, boolean success) {}
            @Override public void onAllDone(int ok, int fail, File outDir) {
                mainHandler.post(() -> {
                    progressBar.setVisibility(View.GONE);
                    btnRipAll.setEnabled(true);
                    tvStatus.setText("Done — " + ok + " ripped, " + fail + " failed.\n" + outDir.getAbsolutePath());
                    for (int i = 0; i < filteredBundles.size(); i++) adapter.markRipped(i);
                });
            }
        }));
    }

    @Override protected void onDestroy() { super.onDestroy(); executor.shutdown(); }
}
