// VrcaParser.java — Unity AssetBundle (.vrca/.vrcw) header parser
// Target: Quest ARM64, VRChat Mobile cache format
// VRCA = VRChat Avatar bundle, VRCW = VRChat World bundle
// Unity AssetBundle magic: 55 6E 69 74 79 46 53 (UnityFS) for LZ4/LZMA compressed
//                          or 55 6E 69 74 79 57 65 62 (UnityWeb) legacy
package com.vrc.rip.core;

import android.util.Log;
import java.io.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.*;

public class VrcaParser {

    private static final String TAG = "VrcaParser";
    private static final byte[] UNITYFS_MAGIC = "UnityFS".getBytes();
    private static final byte[] UNITYWEB_MAGIC = "UnityWeb".getBytes();

    public static class BundleInfo {
        public String filePath;
        public String bundleVersion;    // Unity version string e.g. "2022.3.6f1"
        public long uncompressedSize;
        public long compressedSize;
        public int compressionType;     // 0=none, 1=LZMA, 3=LZ4, 6=LZ4HC
        public String avatarId;         // parsed from filename or internal path
        public byte[] thumbnailPng;     // embedded preview if present
        public boolean isValid;

        @Override
        public String toString() {
            return "BundleInfo{id=" + avatarId + ", size=" + uncompressedSize
                    + ", compression=" + compressionType + ", valid=" + isValid + "}";
        }
    }

    /**
     * Parse UnityFS header from a .vrca or .vrcw file.
     * Does NOT decompress the bundle — just reads the header metadata.
     */
    public static BundleInfo parseHeader(File file) {
        BundleInfo info = new BundleInfo();
        info.filePath = file.getAbsolutePath();
        info.avatarId = extractIdFromFilename(file.getName());

        try (RandomAccessFile raf = new RandomAccessFile(file, "r")) {
            byte[] magic = new byte[7];
            raf.read(magic);

            if (!startsWith(magic, UNITYFS_MAGIC)) {
                // try UnityWeb legacy (8 bytes)
                byte[] magic8 = new byte[8];
                System.arraycopy(magic, 0, magic8, 0, 7);
                magic8[7] = (byte) raf.read();
                if (!startsWith(magic8, UNITYWEB_MAGIC)) {
                    Log.w(TAG, "Not a Unity bundle: " + file.getName());
                    info.isValid = false;
                    return info;
                }
            }

            // skip null terminator after magic
            raf.read(); // 0x00

            // format version (4 bytes BE)
            byte[] verBytes = new byte[4];
            raf.read(verBytes);
            int formatVersion = readIntBE(verBytes, 0);

            // Unity version string (null-terminated)
            info.bundleVersion = readNullTermString(raf);

            // generator version string (null-terminated)
            String generatorVersion = readNullTermString(raf);

            if (formatVersion >= 6) {
                // UnityFS header (format 6+)
                // file size (8 bytes BE)
                byte[] tmp8 = new byte[8];
                raf.read(tmp8);
                long fileSize = readLongBE(tmp8, 0);

                // compressed header size (4 bytes BE)
                byte[] tmp4 = new byte[4];
                raf.read(tmp4);
                long compressedHeaderSize = readIntBE(tmp4, 0) & 0xFFFFFFFFL;

                // uncompressed header size (4 bytes BE)
                raf.read(tmp4);
                long uncompressedHeaderSize = readIntBE(tmp4, 0) & 0xFFFFFFFFL;

                // flags (4 bytes BE)
                raf.read(tmp4);
                int flags = readIntBE(tmp4, 0);
                info.compressionType = flags & 0x3F; // bits 0-5

                info.compressedSize = compressedHeaderSize;
                info.uncompressedSize = fileSize;
            } else {
                // legacy format — basic fields
                byte[] tmp4 = new byte[4];
                raf.read(tmp4);
                info.uncompressedSize = readIntBE(tmp4, 0) & 0xFFFFFFFFL;
                raf.read(tmp4);
                info.compressedSize = readIntBE(tmp4, 0) & 0xFFFFFFFFL;
            }

            info.isValid = true;

            // attempt thumbnail extraction (embedded PNG at known offsets in some builds)
            info.thumbnailPng = findEmbeddedPng(file);

        } catch (IOException e) {
            Log.e(TAG, "Parse failed: " + file.getName(), e);
            info.isValid = false;
        }

        return info;
    }

    /**
     * Scan file bytes for PNG magic (89 50 4E 47) — VRChat embeds a preview PNG
     * inside the bundle for the avatar thumbnail shown in the UI.
     * Returns first found PNG blob, or null.
     */
    public static byte[] findEmbeddedPng(File file) {
        final byte[] PNG_MAGIC = {(byte)0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A};
        final byte[] PNG_END   = {0x49, 0x45, 0x4E, 0x44, (byte)0xAE, 0x42, 0x60, (byte)0x82};

        try (RandomAccessFile raf = new RandomAccessFile(file, "r")) {
            long fileLen = raf.length();
            // read in 64KB chunks, sliding window
            byte[] buf = new byte[65536];
            long pos = 0;
            int overlap = 16;
            int startOffset = -1;

            while (pos < fileLen) {
                raf.seek(pos);
                int read = raf.read(buf);
                if (read <= 0) break;

                for (int i = 0; i < read - PNG_MAGIC.length; i++) {
                    if (startOffset < 0 && matchBytes(buf, i, PNG_MAGIC)) {
                        startOffset = (int)(pos + i);
                    }
                    if (startOffset >= 0 && matchBytes(buf, i, PNG_END)) {
                        long endOffset = pos + i + PNG_END.length;
                        int pngLen = (int)(endOffset - startOffset);
                        if (pngLen > 0 && pngLen < 4 * 1024 * 1024) { // sanity: <4MB
                            byte[] png = new byte[pngLen];
                            raf.seek(startOffset);
                            raf.readFully(png);
                            return png;
                        }
                        startOffset = -1;
                    }
                }
                pos += read - overlap;
            }
        } catch (IOException e) {
            Log.w(TAG, "PNG scan failed: " + file.getName());
        }
        return null;
    }

    /**
     * VRChat cache filename format (mobile): avtr_XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX__AvatarId
     * or just the avatar GUID as the filename with no extension.
     */
    public static String extractIdFromFilename(String name) {
        // strip extension
        int dot = name.lastIndexOf('.');
        if (dot > 0) name = name.substring(0, dot);

        // look for avtr_ prefix UUID pattern
        int idx = name.indexOf("avtr_");
        if (idx >= 0) {
            String sub = name.substring(idx);
            // avtr_xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx is 41 chars
            if (sub.length() >= 41) return sub.substring(0, 41);
        }

        // fallback: raw UUID pattern
        if (name.matches("[0-9a-fA-F\\-]{36}")) return name;

        return name; // unknown format, return as-is
    }

    // ---- byte utils ----

    private static boolean startsWith(byte[] data, byte[] prefix) {
        if (data.length < prefix.length) return false;
        for (int i = 0; i < prefix.length; i++) {
            if (data[i] != prefix[i]) return false;
        }
        return true;
    }

    private static boolean matchBytes(byte[] buf, int offset, byte[] pattern) {
        if (offset + pattern.length > buf.length) return false;
        for (int i = 0; i < pattern.length; i++) {
            if (buf[offset + i] != pattern[i]) return false;
        }
        return true;
    }

    private static int readIntBE(byte[] b, int off) {
        return ((b[off] & 0xFF) << 24) | ((b[off+1] & 0xFF) << 16)
             | ((b[off+2] & 0xFF) << 8)  |  (b[off+3] & 0xFF);
    }

    private static long readLongBE(byte[] b, int off) {
        return ((long)(b[off]   & 0xFF) << 56) | ((long)(b[off+1] & 0xFF) << 48)
             | ((long)(b[off+2] & 0xFF) << 40) | ((long)(b[off+3] & 0xFF) << 32)
             | ((long)(b[off+4] & 0xFF) << 24) | ((long)(b[off+5] & 0xFF) << 16)
             | ((long)(b[off+6] & 0xFF) <<  8) |  (long)(b[off+7] & 0xFF);
    }

    private static String readNullTermString(RandomAccessFile raf) throws IOException {
        StringBuilder sb = new StringBuilder();
        int b;
        while ((b = raf.read()) > 0) sb.append((char) b);
        return sb.toString();
    }
}
