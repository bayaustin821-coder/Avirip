// StoragePermissionHelper.java
// Android 11+ requires MANAGE_EXTERNAL_STORAGE for reading other app cache dirs.
// On Quest this is granted via ADB or the system permission dialog.
package com.vrc.rip.util;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class StoragePermissionHelper {

    public static final int REQUEST_MANAGE_STORAGE = 101;
    public static final int REQUEST_LEGACY_STORAGE = 102;

    public static boolean hasStoragePermission(Activity activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // API 30+ — need MANAGE_EXTERNAL_STORAGE
            return Environment.isExternalStorageManager();
        } else {
            // API 29 — READ_EXTERNAL_STORAGE is enough
            return ContextCompat.checkSelfPermission(activity,
                    Manifest.permission.READ_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_GRANTED;
        }
    }

    public static void requestStoragePermission(Activity activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // open system permission screen for MANAGE_EXTERNAL_STORAGE
            try {
                Intent intent = new Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:" + activity.getPackageName())
                );
                activity.startActivityForResult(intent, REQUEST_MANAGE_STORAGE);
            } catch (Exception e) {
                // fallback: open general manage storage screen
                Intent intent = new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                activity.startActivityForResult(intent, REQUEST_MANAGE_STORAGE);
            }
        } else {
            ActivityCompat.requestPermissions(activity,
                new String[]{
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                },
                REQUEST_LEGACY_STORAGE
            );
        }
    }

    /**
     * Alternative: grant via ADB (no user interaction needed on developer headsets)
     * adb shell appops set com.vrc.rip MANAGE_EXTERNAL_STORAGE allow
     * adb shell pm grant com.vrc.rip android.permission.READ_EXTERNAL_STORAGE
     * adb shell pm grant com.vrc.rip android.permission.WRITE_EXTERNAL_STORAGE
     */
    public static String getAdbGrantCommand(String packageName) {
        return "adb shell appops set " + packageName + " MANAGE_EXTERNAL_STORAGE allow\n" +
               "adb shell pm grant " + packageName + " android.permission.READ_EXTERNAL_STORAGE\n" +
               "adb shell pm grant " + packageName + " android.permission.WRITE_EXTERNAL_STORAGE";
    }
}
