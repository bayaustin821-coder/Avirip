// LoginActivity.java — VRChat login screen, handles password + optional 2FA TOTP
package com.vrc.rip.ui;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.vrc.rip.R;
import com.vrc.rip.network.VRChatApiManager;

public class LoginActivity extends AppCompatActivity {

    private EditText etUsername, etPassword, et2FA;
    private Button btnLogin;
    private TextView tvStatus;
    private LinearLayout layout2FA;
    private ProgressBar progressBar;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // skip login if already have a valid session
        VRChatApiManager api = VRChatApiManager.get(this);
        if (api.isLoggedIn()) {
            goToMain();
            return;
        }

        setContentView(R.layout.activity_login);

        etUsername  = findViewById(R.id.et_username);
        etPassword  = findViewById(R.id.et_password);
        et2FA       = findViewById(R.id.et_2fa);
        btnLogin    = findViewById(R.id.btn_login);
        tvStatus    = findViewById(R.id.tv_status);
        layout2FA   = findViewById(R.id.layout_2fa);
        progressBar = findViewById(R.id.progress_bar);

        btnLogin.setOnClickListener(v -> {
            String user = etUsername.getText().toString().trim();
            String pass = etPassword.getText().toString();
            if (user.isEmpty() || pass.isEmpty()) {
                tvStatus.setText("Username and password required.");
                return;
            }
            startLogin(user, pass);
        });
    }

    private void startLogin(String user, String pass) {
        setLoading(true);
        tvStatus.setText("Logging in...");

        VRChatApiManager.get(this).login(user, pass, new VRChatApiManager.ApiCallback<>() {
            @Override public void onSuccess(com.google.gson.JsonObject result) {
                mainHandler.post(() -> {
                    setLoading(false);
                    tvStatus.setText("Logged in as " + VRChatApiManager.get(LoginActivity.this).getDisplayName());
                    goToMain();
                });
            }

            @Override public void onError(String error, int code) {
                mainHandler.post(() -> {
                    setLoading(false);
                    if ("2FA_REQUIRED".equals(error)) {
                        layout2FA.setVisibility(View.VISIBLE);
                        tvStatus.setText("2FA required — enter your authenticator code.");
                        btnLogin.setText("Verify");
                        // re-wire button to submit 2FA
                        btnLogin.setOnClickListener(v -> submit2FA());
                    } else {
                        tvStatus.setText("Login failed: " + error);
                    }
                });
            }
        });
    }

    private void submit2FA() {
        String code = et2FA.getText().toString().trim();
        if (code.isEmpty()) { tvStatus.setText("Enter your 6-digit 2FA code."); return; }
        setLoading(true);
        tvStatus.setText("Verifying 2FA...");

        VRChatApiManager.get(this).submit2FA(code, new VRChatApiManager.ApiCallback<>() {
            @Override public void onSuccess(com.google.gson.JsonObject r) {
                mainHandler.post(() -> { setLoading(false); goToMain(); });
            }
            @Override public void onError(String error, int code) {
                mainHandler.post(() -> { setLoading(false); tvStatus.setText("2FA failed: " + error); });
            }
        });
    }

    private void goToMain() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }

    private void setLoading(boolean loading) {
        progressBar.setVisibility(loading ? View.VISIBLE : View.GONE);
        btnLogin.setEnabled(!loading);
        etUsername.setEnabled(!loading);
        etPassword.setEnabled(!loading);
    }
}
