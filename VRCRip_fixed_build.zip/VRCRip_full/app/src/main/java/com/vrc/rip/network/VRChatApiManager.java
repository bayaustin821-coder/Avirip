// VRChatApiManager.java — VRChat unofficial REST API client
// Endpoint base: https://api.vrchat.cloud/api/1/
// Auth: Basic auth on /auth/user → returns Set-Cookie with auth + apiKey
// All subsequent calls use cookie jar (auth cookie persists session)
package com.vrc.rip.network;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import okhttp3.*;

import java.io.*;
import java.util.concurrent.TimeUnit;

public class VRChatApiManager {

    private static final String TAG = "VRChatApi";
    private static final String BASE_URL = "https://api.vrchat.cloud/api/1/";
    // VRChat requires a User-Agent or rejects requests
    private static final String USER_AGENT = "VRCRip/2.0 (Quest; Android)";
    private static final String PREFS_NAME = "vrc_session";
    private static final String KEY_AUTH_COOKIE = "auth_cookie";
    private static final String KEY_API_KEY = "api_key";
    private static final String KEY_USER_ID = "user_id";
    private static final String KEY_DISPLAY_NAME = "display_name";

    private static VRChatApiManager instance;
    private final OkHttpClient client;
    private final Gson gson = new Gson();
    private final SharedPreferences prefs;
    private final CookieJar cookieJar;

    // in-memory cookie store (auth + apiKey cookies)
    private String authCookie = null;
    private String apiKey = null;
    private String currentUserId = null;
    private String currentDisplayName = null;

    public interface ApiCallback<T> {
        void onSuccess(T result);
        void onError(String error, int httpCode);
    }

    private VRChatApiManager(Context ctx) {
        prefs = ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);

        // restore saved session
        authCookie = prefs.getString(KEY_AUTH_COOKIE, null);
        apiKey = prefs.getString(KEY_API_KEY, null);
        currentUserId = prefs.getString(KEY_USER_ID, null);
        currentDisplayName = prefs.getString(KEY_DISPLAY_NAME, null);

        cookieJar = new CookieJar() {
            private java.util.List<Cookie> cookies = new java.util.ArrayList<>();

            @Override
            public void saveFromResponse(HttpUrl url, java.util.List<Cookie> newCookies) {
                cookies.addAll(newCookies);
                for (Cookie c : newCookies) {
                    if (c.name().equals("auth")) authCookie = c.name() + "=" + c.value();
                    if (c.name().equals("apiKey")) apiKey = c.value();
                }
                persistSession();
            }

            @Override
            public java.util.List<Cookie> loadForRequest(HttpUrl url) { return cookies; }
        };

        client = new OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(120, TimeUnit.SECONDS)
            .cookieJar(cookieJar)
            .addInterceptor(chain -> {
                Request original = chain.request();
                Request.Builder rb = original.newBuilder()
                    .header("User-Agent", USER_AGENT)
                    .header("Accept", "application/json");
                // attach auth cookie manually if jar didn't pick it up
                if (authCookie != null && !original.url().toString().contains("/auth/user")) {
                    String existing = original.header("Cookie");
                    String combined = (existing != null ? existing + "; " : "") + authCookie;
                    rb.header("Cookie", combined);
                }
                return chain.proceed(rb.build());
            })
            .build();
    }

    public static synchronized VRChatApiManager get(Context ctx) {
        if (instance == null) instance = new VRChatApiManager(ctx.getApplicationContext());
        return instance;
    }

    public boolean isLoggedIn() { return authCookie != null && currentUserId != null; }
    public String getCurrentUserId() { return currentUserId; }
    public String getDisplayName() { return currentDisplayName; }

    // ---- AUTH ----

    /**
     * Login with username + password.
     * VRChat uses HTTP Basic auth on /auth/user, then may require 2FA via /auth/twofactorauth/totp/verify
     */
    public void login(String username, String password, ApiCallback<JsonObject> cb) {
        String creds = Base64.encodeToString(
            (username.trim() + ":" + password).getBytes(), Base64.NO_WRAP);

        Request req = new Request.Builder()
            .url(BASE_URL + "auth/user")
            .header("Authorization", "Basic " + creds)
            .get()
            .build();

        executeAsync(req, (body, code) -> {
            if (code == 200 && body != null) {
                try {
                    JsonObject json = JsonParser.parseString(body).getAsJsonObject();

                    // check for 2FA requirement
                    if (json.has("requiresTwoFactorAuth")) {
                        cb.onError("2FA_REQUIRED", 200);
                        return;
                    }

                    currentUserId = json.has("id") ? json.get("id").getAsString() : null;
                    currentDisplayName = json.has("displayName") ? json.get("displayName").getAsString() : username;
                    persistSession();
                    cb.onSuccess(json);
                } catch (Exception e) {
                    cb.onError("Parse error: " + e.getMessage(), code);
                }
            } else {
                cb.onError(body != null ? body : "HTTP " + code, code);
            }
        });
    }

    /**
     * Submit TOTP code for 2FA
     */
    public void submit2FA(String totpCode, ApiCallback<JsonObject> cb) {
        JsonObject body = new JsonObject();
        body.addProperty("code", totpCode.trim());

        Request req = new Request.Builder()
            .url(BASE_URL + "auth/twofactorauth/totp/verify")
            .post(RequestBody.create(gson.toJson(body), MediaType.get("application/json")))
            .build();

        executeAsync(req, (respBody, code) -> {
            if (code == 200) {
                // re-fetch user after 2FA
                fetchCurrentUser(cb);
            } else {
                cb.onError(respBody != null ? respBody : "2FA failed", code);
            }
        });
    }

    public void fetchCurrentUser(ApiCallback<JsonObject> cb) {
        Request req = new Request.Builder().url(BASE_URL + "auth/user").get().build();
        executeAsync(req, (body, code) -> {
            if (code == 200 && body != null) {
                try {
                    JsonObject json = JsonParser.parseString(body).getAsJsonObject();
                    currentUserId = json.get("id").getAsString();
                    currentDisplayName = json.get("displayName").getAsString();
                    persistSession();
                    cb.onSuccess(json);
                } catch (Exception e) { cb.onError(e.getMessage(), code); }
            } else { cb.onError(body, code); }
        });
    }

    public void logout() {
        authCookie = null;
        apiKey = null;
        currentUserId = null;
        currentDisplayName = null;
        prefs.edit().clear().apply();
        instance = null; // force fresh instance next login
    }

    // ---- AVATAR UPLOAD ----

    /**
     * Upload a .vrca file as a new avatar on the logged-in account.
     *
     * VRChat upload flow (3 steps):
     *   1. POST /file  — create file record, get fileId
     *   2. PUT  /file/{fileId}/1/file  — upload raw VRCA bytes
     *   3. POST /avatars  — create avatar record pointing at fileId
     *
     * Note: VRChat normally also requires a separate thumbnail image upload via
     * /file/{imageFileId}/... — we send a blank 256x256 PNG if no thumbnail available.
     */
    public void uploadAvatar(String avatarId, String displayName, File vrcaFile,
                             byte[] thumbnailPng, ApiCallback<JsonObject> cb) {
        if (!isLoggedIn()) { cb.onError("Not logged in", 401); return; }

        // ApiCallback has two abstract methods, so use anonymous classes
        // rather than lambdas for these callbacks.
        createFileRecord(vrcaFile.getName(), "application/x-avatar",
            new ApiCallback<JsonObject>() {
                @Override
                public void onSuccess(JsonObject fileJson) {
                    if (fileJson == null) {
                        cb.onError("Failed to create file record", 0);
                        return;
                    }

                    String fileId = fileJson.get("id").getAsString();

                    uploadFileData(fileId, vrcaFile, new ApiCallback<Boolean>() {
                        @Override
                        public void onSuccess(Boolean uploadOk) {
                            if (!Boolean.TRUE.equals(uploadOk)) {
                                cb.onError("File upload failed", 0);
                                return;
                            }

                            byte[] thumb = (thumbnailPng != null && thumbnailPng.length > 0)
                                ? thumbnailPng : makeBlankPng();

                            createFileRecord("thumbnail.png", "image/png",
                                new ApiCallback<JsonObject>() {
                                    @Override
                                    public void onSuccess(JsonObject thumbJson) {
                                        if (thumbJson == null) {
                                            cb.onError("Thumbnail record failed", 0);
                                            return;
                                        }

                                        String thumbId = thumbJson.get("id").getAsString();

                                        uploadRawBytes(thumbId, thumb, "image/png",
                                            new ApiCallback<Boolean>() {
                                                @Override
                                                public void onSuccess(Boolean thumbOk) {
                                                    if (!Boolean.TRUE.equals(thumbOk)) {
                                                        cb.onError("Thumbnail upload failed", 0);
                                                        return;
                                                    }
                                                    createAvatarRecord(
                                                        avatarId, displayName, fileId, thumbId, cb
                                                    );
                                                }

                                                @Override
                                                public void onError(String error, int httpCode) {
                                                    cb.onError(error, httpCode);
                                                }
                                            });
                                    }

                                    @Override
                                    public void onError(String error, int httpCode) {
                                        cb.onError(error, httpCode);
                                    }
                                });
                        }

                        @Override
                        public void onError(String error, int httpCode) {
                            cb.onError(error, httpCode);
                        }
                    });
                }

                @Override
                public void onError(String error, int httpCode) {
                    cb.onError(error, httpCode);
                }
            });
    }

    private void createFileRecord(String name, String mimeType, ApiCallback<JsonObject> cb) {
        JsonObject body = new JsonObject();
        body.addProperty("name", name);
        body.addProperty("mimeType", mimeType);
        body.addProperty("extension", mimeType.contains("avatar") ? ".vrca" : ".png");

        Request req = new Request.Builder()
            .url(BASE_URL + "file")
            .post(RequestBody.create(gson.toJson(body), MediaType.get("application/json")))
            .build();

        executeAsync(req, (respBody, code) -> {
            if (code == 200 && respBody != null) {
                cb.onSuccess(JsonParser.parseString(respBody).getAsJsonObject());
            } else {
                cb.onError(respBody, code);
            }
        });
    }

    private void uploadFileData(String fileId, File file, ApiCallback<Boolean> cb) {
        try {
            RequestBody body = RequestBody.create(file, MediaType.get("application/x-avatar"));
            Request req = new Request.Builder()
                .url(BASE_URL + "file/" + fileId + "/1/file")
                .put(body)
                .build();
            executeAsync(req, (respBody, code) -> cb.onSuccess(code == 200));
        } catch (Exception e) { cb.onError(e.getMessage(), 0); }
    }

    private void uploadRawBytes(String fileId, byte[] data, String mime, ApiCallback<Boolean> cb) {
        RequestBody body = RequestBody.create(data, MediaType.get(mime));
        Request req = new Request.Builder()
            .url(BASE_URL + "file/" + fileId + "/1/file")
            .put(body)
            .build();
        executeAsync(req, (respBody, code) -> cb.onSuccess(code == 200));
    }

    private void createAvatarRecord(String localId, String displayName,
                                    String assetFileId, String imageFileId,
                                    ApiCallback<JsonObject> cb) {
        JsonObject body = new JsonObject();
        // VRChat will assign a new avtr_ ID server-side; local ID goes in the name tag
        body.addProperty("name", displayName.isEmpty() ? localId : displayName);
        body.addProperty("description", "Ripped via VRCRip");
        body.addProperty("assetUrl", BASE_URL + "file/" + assetFileId + "/1/file");
        body.addProperty("imageUrl", BASE_URL + "file/" + imageFileId + "/1/file");
        body.addProperty("releaseStatus", "private"); // private by default
        body.addProperty("version", 1);
        // platform tag for Quest
        JsonObject unityPackage = new JsonObject();
        unityPackage.addProperty("platform", "android");
        unityPackage.addProperty("assetUrl", BASE_URL + "file/" + assetFileId + "/1/file");
        body.add("unityPackages", gson.toJsonTree(new JsonObject[]{unityPackage}));

        Request req = new Request.Builder()
            .url(BASE_URL + "avatars")
            .post(RequestBody.create(gson.toJson(body), MediaType.get("application/json")))
            .build();

        executeAsync(req, (respBody, code) -> {
            if (code == 200 && respBody != null) {
                cb.onSuccess(JsonParser.parseString(respBody).getAsJsonObject());
            } else {
                cb.onError(respBody != null ? respBody : "Avatar create failed HTTP " + code, code);
            }
        });
    }

    // ---- FETCH MY AVATARS ----

    public void getMyAvatars(ApiCallback<String> cb) {
        if (!isLoggedIn()) { cb.onError("Not logged in", 401); return; }
        Request req = new Request.Builder()
            .url(BASE_URL + "avatars?releaseStatus=all&user=me&n=100")
            .get().build();
        executeAsync(req, (body, code) -> {
            if (code == 200) cb.onSuccess(body);
            else cb.onError(body, code);
        });
    }

    // ---- INTERNAL ----

    interface RawCallback {
        void onDone(String body, int code);
    }

    private void executeAsync(Request req, RawCallback cb) {
        client.newCall(req).enqueue(new Callback() {
            @Override public void onFailure(Call call, IOException e) {
                Log.e(TAG, "Request failed: " + e.getMessage());
                cb.onDone(e.getMessage(), 0);
            }
            @Override public void onResponse(Call call, Response resp) throws IOException {
                String body = resp.body() != null ? resp.body().string() : null;
                int code = resp.code();
                Log.d(TAG, "← " + code + " " + req.url().encodedPath());
                cb.onDone(body, code);
            }
        });
    }

    private void persistSession() {
        prefs.edit()
            .putString(KEY_AUTH_COOKIE, authCookie)
            .putString(KEY_API_KEY, apiKey)
            .putString(KEY_USER_ID, currentUserId)
            .putString(KEY_DISPLAY_NAME, currentDisplayName)
            .apply();
    }

    // minimal 256x256 solid blue PNG (baseline, not APNG) as placeholder thumbnail
    // pre-encoded: avoids needing Canvas/Bitmap at this layer
    private static byte[] makeBlankPng() {
        // 1x1 pixel solid #0F3460 PNG, Base64-decoded at runtime
        String b64 = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==";
        return Base64.decode(b64, Base64.DEFAULT);
    }
}
